class Card:

  def __init__(self, card_name, card_type):
        self.card_name = card_name
        self.card_type = card_type
